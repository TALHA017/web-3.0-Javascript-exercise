console.log('Write an if statement to test whether the alien’s color is green. If it is, print a message that the player just earned 5 points')
var alien_color = 'green';
if(alien_color == 'green'){
    console.log('player just earned 5 points.');
}
console.log('Write one version of this program that passes the if test and another that fails. (The version that fails will have no output.')
if(alien_color == 'red'){
    console.log(null);
}
