const names = ["Saad", "Hameed", "Hamza"];
names.forEach((name) =>{
    console.log(name)
});