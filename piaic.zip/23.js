let car = 'subaru';
let data = ['subaru','subaru','subaru','subaru','subaru','subarua','subarua','subarua','subarua','subarua'];
console.log("Is car == 'subaru'? I predict True.")
var i= 0;
data.forEach((item)=>{
    console.log(item == 'subaru')
    i++;
})

