let data = ['Isb', 'Rwp', 'Lhr', 'Khi' ];

// let list = document.getElementById("myList");
var i = 0;
data.forEach((item)=>{
    console.log(i+': '+item);
    i++;
})
