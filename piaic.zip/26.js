console.log('Alien Colors #3: Turn your if-else chain from Exercise 5-4 into an if-else chain.')
var data = ['green', 'red'];
data.forEach((alien_color) => {
    if (alien_color == 'green') {
        console.log('When Green:')
        console.log('Version of this program that runs the else block:')

        console.log('player just earned 5 points.');
    }  else {
        console.log('When not green:')
        console.log('Version of this program that runs the else block:')
        console.log('player just earned 10 points.');
    }
})