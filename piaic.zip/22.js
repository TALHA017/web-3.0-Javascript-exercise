let data = ['Isb', 'Rwp', 'Lhr', 'Khi' ];

// let list = document.getElementById("myList");
console.log('Intentional Error: If you haven’t received an array index error in one of your programs yet, try to make one happen. Change an index in one of your programs to produce an index error. Make sure you correct the error before closing the program.')
console.log(data[7]);
console.log('Make sure you correct the error before closing the program.')
console.log('Index Printed: '+data[2]);
